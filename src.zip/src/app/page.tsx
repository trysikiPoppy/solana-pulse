import React from "react";
import TrendingPoolsPage from "@/components/pages/trending-pools-page";

export default function Home(): React.JSX.Element {
  return <TrendingPoolsPage />;
}
